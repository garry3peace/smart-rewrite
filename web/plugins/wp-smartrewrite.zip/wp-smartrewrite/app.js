var is_tinymce_active = function()
{
	return (typeof tinyMCE != "undefined") && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden();
};

var get_content = function()
{
	
	if (is_tinymce_active()){
		return tinyMCE.editors.content.getContent();
	}else{
		return jQuery("#content").val();
	}
};

var set_content = function(content)
{
	if (is_tinymce_active()){
		return tinyMCE.editors.content.setContent(content);
	}else{
		return jQuery("#content").val(content);
	}
};

var sr_submit = function () {
	var params = {
		unique: jQuery("#sr-post-unique:checked").val(),
		exception: jQuery("#sr-post-exception").val(),
		paragraph_reorder: jQuery("#sr-post-paragraph-reorder:checked").val(),
		paragraph_exclude_reorder: jQuery("#sr-post-paragraph-exclude-reorder").val(),
		content: get_content()
	};
	
	jQuery("#source").val(params.content);

	jQuery.post(base_url + "/wp-admin/admin-ajax.php?action=rewrite", params,
		function (raw_text) {
			raw_text = jQuery.parseJSON(raw_text);
			jQuery("#spintax").val(raw_text);
			var result = spintax.unspin(raw_text);
			set_content(result);
		});
};

var sr_revert = function()
{
	var source = jQuery("#source").val();
	if(source){
		var result = source;
		set_content(result);
	}
};