<div class="wrap">
	<form method="post" action="options.php"> 
		<?php settings_fields(SmartRewrite::OPTION_GROUP); ?>
		<?php do_settings_sections( SmartRewrite::PAGE_NAME ); ?>
		<?php submit_button(); ?>
	</form>
</div>