<?php
class SmartRewrite {

	public $options; 
	const TITLE = 'Smart Rewrite';
	
	const PAGE_NAME = 'wp-smartrewrite';
	const OPTION_NAME = 'sr-option-name';
	const OPTION_GROUP = 'sr-option-group';
	
	const URL_API = 'http://localhost:8080/api/default/index';

	/**
	* Fungsi menambah item ke Admin menu
	*/
   function plugin_menu() {
	   add_options_page( 'Smart Rewrite', 'Smart Rewrite', 'manage_options', self::PAGE_NAME, array($this, 'plugin_options'));
   }

   /**
	* Menampilkan halaman
	*/
   function plugin_options() {
	   if ( !current_user_can( 'manage_options' ) )  {
		   wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	   }

	   $this->options = get_option(self::OPTION_NAME);
	   
	   include( plugin_dir_path( __FILE__ ) . 'option-page.php');
   }

	public function register_settings() {
		register_setting(
				self::OPTION_GROUP,
				self::OPTION_NAME,
				array($this, 'sanitize') // Sanitize
		);

		add_settings_section(
				'setting_section_id', 
				self::TITLE,
				array($this, 'print_section_info'),
				self::PAGE_NAME // Page
		);

		add_settings_field(
				'api_key', 
				'API KEY',
				array($this, 'api_key_callback'),
				self::PAGE_NAME,
				'setting_section_id'
		);
		
		add_settings_field(
				'autorewrite', 
				'Auto Rewrite',
				array($this, 'autorewrite_key_callback'),
				self::PAGE_NAME,
				'setting_section_id'
		);
		
		add_settings_field(
				'unique', 
				'Unik',
				array($this, 'unique_callback'),
				self::PAGE_NAME, 
				'setting_section_id'
		);
		
		add_settings_field(
				'exception', 
				'Perkecualian',
				array($this, 'exception_callback'),
				self::PAGE_NAME, 
				'setting_section_id' 
		);
		
		add_settings_field(
				'paragraph_reorder', 
				'Susun Ulang Paragraf',
				array($this, 'paragraph_reorder_callback'),
				self::PAGE_NAME,
				'setting_section_id' 
		);
		
		add_settings_field(
				'paragraph_exclude_reorder', 
				'Paragraf Perkecualian',
				array($this, 'paragraph_exclude_reorder_callback'),
				self::PAGE_NAME,
				'setting_section_id' 
		);
	}

	/**
	 * Sanitize each setting field as needed
	 *
	 * @param array $input Contains all settings fields as array keys
	 */
	public function sanitize($input) {
		$new_input = array();
		$list = array('api_key','autorewrite','unique','exception','paragraph_reorder','paragraph_exclude_reorder');
		
		foreach($list as $item){
			if (isset($input[$item]))
				$new_input[$item] = sanitize_text_field($input[$item]);
		}
		
		return $new_input;
	}
	
	public function get_checked($value)
	{
		return ($this->options[$value]==1) ? 'checked="checked"' : '';
	}
	
	public function get_value($value)
	{
		return isset($this->options[$value]) ? esc_attr($this->options[$value]) : '';
	}

	/////////////////////////////// BELOW IS CUSTOM PLUGIN /////////////////////
	
	/**
	 * Print the Section text
	 */
	public function print_section_info() {
		print 'Konfigurasi nilai berikut ini:';
	}

	public function api_key_callback() {
		printf(
				'<input type="text" id="api_key" name="sr-option-name[api_key]" value="%s" />', $this->get_value('api_key')
		);
	}
	
	public function autorewrite_key_callback() {
		printf(
				'<input type="checkbox" id="autorewrite" name="sr-option-name[autorewrite]" value="1" %s />', $this->get_checked('autorewrite')
		);
	}
	
	public function unique_callback() {
		printf(
				'<input type="checkbox" id="unique" name="sr-option-name[unique]" value="1" %s  />', $this->get_checked('unique')
		);
	}

	public function exception_callback() {
		printf(
				'<input type="text" id="exception" name="sr-option-name[exception]" value="%s" />', $this->get_value('exception')
		);
	}
	
	public function paragraph_reorder_callback() {
		printf(
				'<input type="checkbox" id="paragraph_reorder" name="sr-option-name[paragraph_reorder]" value="1" %s />', $this->get_checked('paragraph_reorder')
		);
	}
	
	public function paragraph_exclude_reorder_callback() {
		printf(
				'<input type="text" id="paragraph_exclude_reorder" name="sr-option-name[paragraph_exclude_reorder]" value="%s" />', $this->get_value('paragraph_exclude_reorder')
		);
	}
	   
   public function custom_button() {
	   $base_url = get_site_url();
	   $script = '<script type="text/javascript">
				window.base_url = "'.$base_url.'";
		</script>';
	   
	   
		$html = '<div id="major-publishing-actions" style="overflow:hidden">';
		$html .= '<div id="smartrewrite-action" >';
		$html .= '<input type="button" onclick="sr_submit()" tabindex="5" value="Smart Rewrite!" class="button-primary" id="smartrewrite" name="smartrewrite">';
		$html .= '&nbsp;<input type="button" onclick="sr_revert()" tabindex="6" value="Revert" class="button-secondary button-small" id="smartrewrite-revert" name="smartrewrite-revert">';
		$html .= '</div>';
		$html .= '</div>';
		echo $script;
		echo $html;
	}
	
	function post_meta_boxes_setup() {
		/* Add meta boxes on the 'add_meta_boxes' hook. */
		add_action('add_meta_boxes', array($this, 'add_post_meta_boxes'));
		add_action('save_post', array($this, 'save_post_class_meta'), 10, 2 );
	}

	public function add_post_meta_boxes() {

		add_meta_box(
				'meta-smartrewrite', // Unique ID
				self::TITLE, // Title
				array($this, 'post_class_meta_box'),
				'post', // Admin page (or post type)
				'normal', // Context
				'default'		 // Priority
		);
	}
	
	/* Display the post meta box. */

	function post_class_meta_box($object, $box) {
?>

		<?php wp_nonce_field(basename(__FILE__), 'post_class_nonce'); ?>

		  <p>
		    <label for="sr-post-unique">Unique</label>
		    <input class="widefat" type="checkbox" name="sr-post-unique" id="sr-post-unique" value="1" <?php echo get_post_meta($object->ID, 'sr-post-paragraph-reorder', true)==1?"checked='checked'":""; ?> /><br/>
			<span class="hint">Jika dicentang, Smart Rewrite akan selalu menggunakan kata penganti.</span>
		  </p>
		  
		  <p>
		    <label for="sr-post-exception">Perkecualian</label>
		    <br />
		    <input class="widefat" type="text" name="sr-post-exception" id="sr-post-exception" value="<?php echo esc_attr(get_post_meta($object->ID, 'sr-post-exception', true)); ?>" size="30" />
			<br/>
			<span class="hint">Masukkan kata-kata dipisah titik koma (;) agar tidak diproses oleh Smart Rewrite.</span>
		  </p>
		  
		  <p>
		    <label for="sr-post-paragraph-reorder">Perkecualian</label>
		    <input class="widefat" type="checkbox" name="sr-post-paragraph-reorder" id="sr-post-paragraph-reorder" value="1" <?php echo get_post_meta($object->ID, 'sr-post-paragraph-reorder', true)==1?"checked='checked'":""; ?>" />
			<br/>
			<span class="hint">Jika dicentang, Smart Rewrite mengacak paragraf.</span>
		  </p>
		  
		  <p>
		    <label for="sr-post-paragraph-exclude-reorder">Paragraf Perkecualian</label>
		    <br />
		    <input class="widefat" type="text" name="sr-post-paragraph-exclude-reorder" id="sr-post-paragraph-exclude-reorder" value="<?php echo esc_attr(get_post_meta($object->ID, 'sr-post-paragraph-exclude-reorder', true)); ?>" size="30" />
			<br/>
			<span class="hint">Hanya berfungsi jika "Acak Paragraf" dinyalakan. Digunakan untuk tidak mengacak paragraf tertentu. Pisah dengan koma. Masukkan angka urutan paragraf yang jangan disusun. Untuk angka dari belakang bisa pakai negatif. Untuk paragraf paling terakhir bisa isi "-1".</span>
		  </p>
		  
		  <input type="hidden" name="source" id="source" />
		  <input type="hidden" name="spintax" id="spintax" />
		  
	<?php
	}
	
	
	/**
	 * Process for saving the meta fields in the editing post page
	 * @param type $post_id
	 * @param type $post
	 * @return type
	 */
	function save_post_class_meta($post_id, $post) {

		/* Verify the nonce before proceeding. */
		if (!isset($_POST['post_class_nonce']) || !wp_verify_nonce($_POST['post_class_nonce'], basename(__FILE__)))
			return $post_id;

		/* Get the post type object. */
		$post_type = get_post_type_object($post->post_type);

		/* Check if the current user has permission to edit the post. */
		if (!current_user_can($post_type->cap->edit_post, $post_id))
			return $post_id;

		/* Get the posted data and sanitize it for use as an HTML class. */
		$new_meta_value = ( isset($_POST['sr-post-unique']) ? sanitize_html_class($_POST['sr-post-unique']) : '' );

		/* Get the meta key. */
		$meta_key = 'sr-post-unique';

		/* Get the meta value of the custom field key. */
		$meta_value = get_post_meta($post_id, $meta_key, true);

		/* If a new meta value was added and there was no previous value, add it. */
		if ($new_meta_value && '' == $meta_value)
			add_post_meta($post_id, $meta_key, $new_meta_value, true);

		/* If the new meta value does not match the old value, update it. */
		elseif ($new_meta_value && $new_meta_value != $meta_value)
			update_post_meta($post_id, $meta_key, $new_meta_value);

		/* If there is no new meta value but an old value exists, delete it. */
		elseif ('' == $new_meta_value && $meta_value)
			delete_post_meta($post_id, $meta_key, $meta_value);
	}
	
	public function rewrite()
	{
		$url = self::URL_API;
		
		$params = array();
		$params['unique'] = ($_POST['unique']==1)?1:0;
		$params['exception'] = $_POST['exception'];
		$params['paragraph_reorder'] = ($_POST['paragraph_reorder']==1)?1:0;
		$params['paragraph_exclude_reorder'] = $_POST['paragraph_exclude_reorder'];
		
		//bungkus semua key dari 'unique' menjadi Spin['unique']
		$args = array();
		foreach($params as $label=>$item){
			$args["Options"][$label] = $item;
		}
		
		//Harus stripcslashes karena jquery.post otomatis escape slashes
		$args['Spin']['content'] = stripcslashes($_POST['content']);
		$args = json_encode($args);
		
		//Harus menggunakan cURL karena WordPress tidak bisa mengirim 
		//POST dalam format application/json
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Content-type: application/json"));
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $args);

		$result = curl_exec($curl);
		echo $result;
		die();
	}
	
	function admin_theme_style() {
		wp_enqueue_style('smartrewrite-admin-theme', plugins_url('wp-admin.css', __FILE__));
		wp_enqueue_script('smartrewrite-mel-spintax', plugins_url('mel-spintax.js', __FILE__));
		wp_enqueue_script('smartrewrite-app-js', plugins_url('app.js', __FILE__));
	}

}


if ( is_admin() ){ // admin actions
	$smart_rewrite = new SmartRewrite();
	//Tambahkan setting
	add_action('admin_init', array($smart_rewrite,'register_settings'));
	
	//Daftarkan menu baru ke Admin Menu
	add_action('admin_menu', array($smart_rewrite,'plugin_menu'));
	
	//Menambah rewrite di atas tombol Submit
	add_action('post_submitbox_misc_actions', array($smart_rewrite, 'custom_button'));
	
	/* Fire our meta box setup function on the post editor screen. */
	add_action( 'load-post.php', array($smart_rewrite, 'post_meta_boxes_setup'));
	add_action( 'load-post-new.php', array($smart_rewrite, 'post_meta_boxes_setup'));
	
	//Akses dengan $.get('index.php/wp-admin/admin-ajax.php?action=rewrite&unique=0&exception=testing', function(data){});
	add_action('wp_ajax_rewrite', array($smart_rewrite, 'rewrite'));
	
	//Tampilan untuk adminz
	add_action('admin_enqueue_scripts', array($smart_rewrite, 'admin_theme_style'));

} else {
  // non-admin enqueues, actions, and filters
}