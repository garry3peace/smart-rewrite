<?php 
/*
Plugin Name: Wordpress SmartRewrite
Plugin URI:  http://www.smartrewrite.com
Description: Auto rewrite content from powered by SmartRewrite
Version:     1.0
Author:      SmartRewrite
Author URI:  http://www.smartrewrite.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: wporg
Domain Path: /languages
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

include( plugin_dir_path( __FILE__ ) . '/smartrewrite.php');
